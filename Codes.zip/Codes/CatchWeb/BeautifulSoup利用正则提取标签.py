import requests
import re
from bs4 import BeautifulSoup
url = "http://python123.io/ws/demo.html"
r = requests.get(url)
demo = r.text
soup = BeautifulSoup(demo, "html.parser")
print(soup.prettify() + "\n")

for tag in soup.find_all(re.complie('b')):#以b开头的所有标签
    print(tag.name)
