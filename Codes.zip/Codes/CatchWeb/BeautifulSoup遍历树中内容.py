import requests
from bs4 import BeautifulSoup
url = "http://python123.io/ws/demo.html"
r = requests.get(url)
demo = r.text
soup = BeautifulSoup(demo, "html.parser")
print(soup.prettify() + "\n")

#print((soup.head.parent)遍历父亲树上内容
#print(soup.a.next_sibling.next_sibling)遍历同层内容

