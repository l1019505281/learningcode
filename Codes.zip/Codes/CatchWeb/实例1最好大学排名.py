import requests
from bs4 import BeautifulSoup
import bs4
def getHTMLText(url):#用request库获取html页面
    try:
        r = requests.get(url, timeout = 30)
        r.raise_for_status()
        r.encoding = r.apparent_encoding
        return r.text
    except:
        print("error")

def fillUnivList(ulist,html):#用bf库解析页面信息并获取想要的信息
    soup = BeautifulSoup(html,"html.parser")
    for tr in soup.find("tbody").children:#找到tbody，并遍历儿子标签
        if isinstance(tr,bs4.element.Tag):
            tds = tr("td")#遍历儿子标签时找到td标签
            ulist.append([tds[0].string, tds[1].string,tds[3].string])#将td标签中元素添加进列表

def printUnivList(ulist,num):
    print("{:^10}\t{:^6}\t{:^10}".format("排名","学校","总分"))
    for i in range(num):
        u = ulist[i]
        print("{:^10}\t{:^6}\t{:^10}".format(u[0],u[1],u[2]))


def main():
    uinfo = []
    url = "http://www.zuihaodaxue.cn/zuihaodaxuepaiming2016.html"
    html = getHTMLText(url)
    fillUnivList(uinfo,html)
    printUnivList(uinfo, 20)



main()
