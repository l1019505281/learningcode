import requests
url = "http://m.ip138.com/ip.asp?"
try:
    kv = {"user-agent":"Mozilla/5.0"}
    ip = {'ip':"222.200.98.147"}
    r = requests.get(url, params = ip)#params是在后面加上字典ip=xxx,headers是改变浏览器访问头的
    #r = requests.get(url)
    r.raise_for_status()
    r.encoding = r.apparent_encoding
    print(r.text[1000:2000])
    print("\n")
    print(r.url)
except:
    print("error")
    print(r.status_code)
