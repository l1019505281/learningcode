import requests
from bs4 import BeautifulSoup
url = "http://python123.io/ws/demo.html"
r = requests.get(url)
demo = r.text
soup = BeautifulSoup(demo, "html.parser")
print(soup.prettify() + "\n")

#find_all(name,attrs,recurisve,string,**kwargs)   而且soup.find_all = soup()

#name标签名,attrs查找标签内容中的指定字符串,,recursive是否对子孙全服搜索

#string搜索指定字符串
for link in soup.find_all('a'):#找到a标签，当括号内为Ture是输出全部标签
    print(link.get('href'))#在a标签中找href标签的内容

soup.find_all('p','course')#找到标签p中有course内容的标签
