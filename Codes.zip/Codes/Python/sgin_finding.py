
# coding: utf-8

# In[1]:


import cv2
import numpy
img=cv2.imread('D:\\sign.jpg')    #如果是图片使用这句
hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
blue_lower=numpy.array([100,80,80])   #颜色过滤
blue_upper=numpy.array([124,255,255])
mask=cv2.inRange(hsv,blue_lower,blue_upper)   #颜色过滤
blurred=cv2.blur(mask,(9,9))   #模糊处理
ret,binary=cv2.threshold(blurred,127,255,cv2.THRESH_BINARY)  #二值化
kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (21, 17))  #使区域闭合无空隙
closed = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel)
erode=cv2.erode(closed,None,iterations=4)  #腐蚀
dilate=cv2.dilate(erode,None,iterations=4)  #膨胀
image,contours, hierarchy=cv2.findContours(dilate.copy(), cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
print('轮廓个数：',len(contours))
i=0
res=img.copy()
for con in contours:
    rect=cv2.minAreaRect(con)
    box=numpy.int0(cv2.boxPoints(rect))
    cv2.drawContours(res,[box],-1,(0,0,255),2)
    print([box])
    h1=max([box][0][0][1],[box][0][1][1],[box][0][2][1],[box][0][3][1])
    h2=min([box][0][0][1],[box][0][1][1],[box][0][2][1],[box][0][3][1])
    l1=max([box][0][0][0],[box][0][1][0],[box][0][2][0],[box][0][3][0])
    l2=min([box][0][0][0],[box][0][1][0],[box][0][2][0],[box][0][3][0])
    print('h1',h1)
    print('h2',h2)
    print('l1',l1)
    print('l2',l2)
    if h1-h2>0 and l1-l2>0:
        temp=img[h2:h1,l2:l1]
        i=i+1
        cv2.imshow('sign'+str(i),temp)
    cv2.imshow('res',res)
    '''
def getdiff(img):
    Sidelength=30
    img=cv2.resize(img,(Sidelength,Sidelength),interpolation=cv2.INTER_CUBIC)
    gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    avglist=[]
    for i in range(Sidelength):
        avg=sum(gray[i])/len(gray[i])
        avglist.append(avg)
        return avglist
    
def getss(list):
    avg=sum(list)/len(list)
    ss=0
    for l in list:
        ss+=(l-avg)*(l-avg)/len(list)   
    return ss
    
walk_sign=cv2.imread('walks_sign.jpg') 
sign_1=getdiff(walk_sign)  #....导入一系列对比标志并计算方差

real_sign = getdiff(temp)  #计算所截图标志的方差

deff_list = [sign_1,'''''']

sign_name =
{
    sign_1 : "人行道标志"，
#.....一系列的标志及标志名称
}
    
for sign in deff_list:
    if abs(real_sign - sign)
    print("这个标志是：" + sign_name[sign])

'''
