import win32api
import win32con
import win32gui
from ctypes import *
import time
from time import sleep


def double_click(x=0, y=0):
    mouse_move(x, y)
    time.sleep(0.05)    #延迟时间，尤其是在电脑反映不是很快的时候，
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0) #点击鼠标
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)  #抬起鼠标
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)
def get_mouse_position():
    po = POINT()
    windll.user32.GetCursorPos(byref(po))
    return int(po.x),int(po.y)
class POINT(Structure):
    fields_=[("x",c_ulong),("y",c_ulong)]
'''
i = get_mouse_position()
print(i)
'''
sleep(5)
win32api.keybd_event(67,0,0,0)
#65 a  90 z

win32api.keybd_event(88,0,0,0)
