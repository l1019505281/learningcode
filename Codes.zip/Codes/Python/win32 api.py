import win32api
import win32con
import win32gui
from ctypes import *
import time


def double_click(x=0, y=0):
    mouse_move(x, y)
    time.sleep(0.05)    #延迟时间，尤其是在电脑反映不是很快的时候，
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0) #点击鼠标
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)  #抬起鼠标
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)
