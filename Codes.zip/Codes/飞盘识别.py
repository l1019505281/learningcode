import cv2
import numpy
import matplotlib.pyplot as plt
import argparse
i=[0,0,0]
img = cv2.imread('blue.jpg')
img = cv2.GaussianBlur(img,(3,3),0) 
#0和1是圆心的xy坐标，2是圆的半径
resize=cv2.resize(img,(600,600),interpolation=cv2.INTER_CUBIC)
gray = cv2.cvtColor(resize, cv2.COLOR_BGR2GRAY)  # 灰度图像
blurred=cv2.blur(gray,(9,9))
ret,binary=cv2.threshold(blurred,130,255,cv2.THRESH_BINARY)
canny = cv2.Canny(blurred, 50, 150)
circles1 = cv2.HoughCircles(binary, cv2.HOUGH_GRADIENT, 1,600, param1=100, param2=15, minRadius=100, maxRadius=800)

res=img.copy()
if not circles1 is None:
    circles = circles1[0, :, :]  # 提取为二维
    circles = numpy.uint16(numpy.around(circles))  # 四舍五入
    print(circles)
    for i in circles[:]:
        l1 = i[0]-i[2]
        l2 = i[0]+i[2]
        h1 = i[1]-i[2]
        h2 = i[1]+i[2]
        cv2.rectangle(resize,(i[0]-i[2],i[1]+i[2]),(i[0]+i[2],i[1]-i[2]),(255,255,0),5)#画出平台区域
        temp=resize[h1:h2,l1:l2]#截出平台区域图像
cv2.imshow('sign',temp)
#cv2.imshow('img',resize)


hsv = cv2.cvtColor(temp, cv2.COLOR_BGR2HSV)#转hsv图像通道
blue_lower=numpy.array([100,80,60])   #颜色过滤
blue_upper=numpy.array([155,255,255])
mask=cv2.inRange(hsv,blue_lower,blue_upper)   #颜色过滤
blurred_1=cv2.blur(mask,(9,9))   #模糊处理
ret,binary_1=cv2.threshold(blurred_1,127,255,cv2.THRESH_BINARY)  #二值化
kernel_1 = cv2.getStructuringElement(cv2.MORPH_RECT, (21, 17))  #使区域闭合无空隙
closed_1 = cv2.morphologyEx(binary_1, cv2.MORPH_CLOSE, kernel_1)
erode_1=cv2.erode(closed_1,None,iterations=4)  #腐蚀
dilate_1=cv2.dilate(erode_1,None,iterations=4)  #膨胀
image,contours, hierarchy=cv2.findContours(dilate_1.copy(), cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
print('轮廓个数：',len(contours))
i=0
res=img.copy()
for con in contours:
    rect=cv2.minAreaRect(con)
    box=numpy.int0(cv2.boxPoints(rect))
    cv2.drawContours(temp,[box],-1,(0,0,255),2)#画出蓝色区域
    print("box", [box])
    h3=max([box][0][0][1],[box][0][1][1],[box][0][2][1],[box][0][3][1])
    h4=min([box][0][0][1],[box][0][1][1],[box][0][2][1],[box][0][3][1])
    l3=max([box][0][0][0],[box][0][1][0],[box][0][2][0],[box][0][3][0])
    l4=min([box][0][0][0],[box][0][1][0],[box][0][2][0],[box][0][3][0])
    print('h3',h3)
    print('h4',h4)
    print('l3',l3)
    print('l4',l4)
    if h3-h4>0 and l3-l4>0:
        temp_1=temp[h4:h3,l4:l3]#截出蓝色飞盘区域
        i=i+1
        #cv2.imshow('sign'+str(i),temp_1)
resize = cv2.putText(resize,"123",(h3,l3),cv2.FONT_HERSHEY_SIMPLEX,1,(0,0,255),1)
cv2.imshow('mask',mask)
cv2.imshow('closed_1',closed_1)
cv2.imshow('result',resize)
'''
cv2.imshow("platform",temp)
cv2.imshow("hsv",hsv)
cv2.imshow("mask",mask)
'''
