import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt

def add_layer(inputs,in_size,out_size,activation_function = None):
    Weights = tf.Variable(tf.random_normal([in_size,out_size]))
    biases = tf.Variable(tf.zeros([1,out_size]) + 0.1)
    Wx_plus_b = tf.matmul(inputs,Weights) + biases
    if activation_function is None:
        outputs = Wx_plus_b
    else:
        outputs = activation_function(Wx_plus_b)
    return outputs          #构建添加神经网络函数

x_data = np.array([[24.1],[29.3],[34.7],[39.9],[45.0],[49.7],[54.3],[59.3],[65.0],[70.1]])  #300个的随机数据，训练模型拟合出这个随机数的的曲线
noise = np.random.normal(0,0.05,x_data.shape)
y_data = np.array([[4100.0],[3400.0],[2900.0],[2400.0],[2000.0],[1750.0],[1500.0],[1300.0],[1130.0],[990.0]]) #构造输入数据（应用时是输入数据切片分为训练集和测试集）     y=x平方-0.5+噪点

xs = tf.placeholder(tf.float32,[None,1])#用来传变量入tensorflow（可能tf的数据与普通数据不同要进行处理之后才能应用
ys = tf.placeholder(tf.float32,[None,1])

##                    构建神经网络
layer1 = add_layer(xs,1,10,activation_function = tf.sigmoid)#第一层
predition = add_layer(layer1,10,1,activation_function = None)#第二层（输出预测结果
#x是1-300而predition是预测1-300上y的值，也就是predition是y的预测值
loss = tf.reduce_mean(tf.reduce_sum(tf.square(y_data - predition),
                     reduction_indices = [1]))#[0]按列求和[1]按行求和
##


train_step = tf.train.GradientDescentOptimizer(0.8).minimize(loss)  #设置训练的优化器

init = tf.global_variables_initializer()

with tf.Session() as sess:
    sess.run(init)
    fig = plt.figure()
    ax = fig.add_subplot(1,1,1)
    ax.scatter(x_data,y_data,marker=".")# 将300个数据显示出来
    plt.xlim(0,71)
    plt.ylim(900,4120)
    plt.ion()
    plt.show()
    for epoch in range(7000):
        sess.run(train_step,feed_dict = {xs:x_data,ys:y_data})
        if epoch % 50 == 0:
            try:
                ax.lines.remove(lines[0])
            except Exception:
                pass
            prediction_value = sess.run(predition,feed_dict={xs:x_data})
            lines = ax.plot(x_data,prediction_value,'r-',lw=1)
            plt.pause(0.2)
            print('loss:',sess.run(loss,feed_dict = {xs:x_data,ys:y_data}))
   # print("pre",sess.run(predition,feed_dict = {xs:x_data,ys:y_data}))
   # print("ys:",sess.run(ys,feed_dict = {ys:y_data}))
   # print("y_data:",y_data)
