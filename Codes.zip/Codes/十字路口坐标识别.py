import cv2
import math
import numpy as np
def calculate_line(x1, y1, x2, y2):
    '''
    计算直线
    如果直线水平或者垂直，统一向一个方向倾斜特定角度。
    TODO 这里面没有考虑水平或者垂直的情况
    '''
    if x1 > x2:
        x1,y1,x2,y2 = x2,y2,x1,y1
        k = (y2 - y1) / (x2 - x1)
        b = -k*x1+y1
    elif x1 == x2 :
        # 有时候会出现单个像素点 x1 = x2 而且 y1 = y2
        k=500
        b = -k*x1+y1
        print('x1:{} y1:{} x2:{} y2:{}'.format(x1, y1, x2, y2))
    else:
        k = (y2 - y1) / (x2 - x1)
        b = -k*x1+y1
    
    return k,b
def calculate_intersection(line1, line2):
    a1 = line1['y2'] - line1['y1']
    b1 = line1['x1'] - line1['x2']
    c1 = line1['x2'] * line1['y1'] - line1['x1'] * line1['y2']
    
    a2 = line2['y2'] - line2['y1']
    b2 = line2['x1'] - line2['x2']
    c2 = line2['x2'] * line2['y1'] - line2['x1'] * line2['y2']
    
    if (a1 * b2 - a2 * b1) != 0 and (a2 * b1 - a1 * b2) != 0:
        cross_x = int((b1*c2-b2*c1)/(a1*b2-a2*b1))
        cross_y = int((c1*a2-c2*a1)/(a1*b2-a2*b1))
        return (cross_x, cross_y)
    return None

img=cv2.imread("C:\\Users\\Kagami\\Desktop\\line.jpg")
canvas = np.zeros((287,405,3), dtype ="uint8")
HSV = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
H, S, V = cv2.split(HSV)
LowerBlue = np.array([0, 0, 150])
UpperBlue = np.array([180, 50, 255])
mask = cv2.inRange(HSV, LowerBlue, UpperBlue)
BlueThings = cv2.bitwise_and(img, img, mask=mask)
#抽取白色部分
BlueThingsG = cv2.cvtColor(BlueThings, cv2.COLOR_BGR2GRAY)
ret,binary = cv2.threshold(BlueThingsG,127,255,cv2.THRESH_BINARY) 

dst=cv2.medianBlur(binary, 5)
kernel = cv2.getStructuringElement(cv2.MORPH_RECT,(3, 3))
erosion = cv2.morphologyEx(dst, cv2.MORPH_OPEN, kernel)
#模糊腐蚀膨胀

line_segs = cv2.HoughLinesP(erosion, rho=2,theta=0.1, threshold=100)
print(len(line_segs))
for lseg in line_segs:
    # 
    x1,y1,x2,y2 = lseg[0]
    # 计算权重
    weight = math.sqrt(math.pow(x1-x2, 2) + math.pow(y1-y2, 2))
    k,b=calculate_line(x1, y1, x2, y2)
    print('x1: {}, y1: {}, x2: {}, y2: {}, weight: {}, k: {}, b: {}'.format(x1, y1, x2, y2, weight,k,b))

lines = []
# 最小权值
min_weight = 20
# 相同k之间最大的差距
max_k_distance = 0.3

for lseg in line_segs:
    # 获取线段端点值
    x1,y1,x2,y2 = lseg[0]
    if x1 > x2:
        x1, y1, x2, y2 = x2, y2, x1, y1
        
    # 计算权重
    weight = math.sqrt(math.pow(x1 - x2, 2) + math.pow(y1 - y2, 2))
    
    if weight != 0 and weight > min_weight:
        # 计算K与b
        k, b = calculate_line(x1, y1, x2, y2)
        # print('k: {:.2f}, b: {:.2f}, weight: {:.2f}'.format(k, b, weight))
        
        if len(lines) == 0:
            # 初次填充line
            line = {}
            line['cur_k'] = k
            line['cur_b'] = b
            line['k_sum'] = k * weight
            line['b_sum'] = b * weight
            line['weight_sum'] = weight
            line['x1'] = x1
            line['y1'] = y1
            line['x2'] = x2
            line['y2'] = y2
            lines.append(line)
            continue
        
        # 根据k的差异做加权
        # 首先获取lines数组里面k举例最近的那个
        
        neighbor_line = min(lines, key=lambda line:abs(line['cur_k'] - k))
        
        if  abs(neighbor_line['cur_k'] - k) < max_k_distance:
            # 小于最大k差值，认为是同一条线
            
            neighbor_line['weight_sum'] += weight
            neighbor_line['k_sum'] += k * weight
            neighbor_line['b_sum'] += b * weight
            neighbor_line['cur_k'] = neighbor_line['k_sum'] / neighbor_line['weight_sum']
            neighbor_line['cur_b'] = neighbor_line['b_sum'] / neighbor_line['weight_sum']
            
            if neighbor_line['x1'] > x1:
                neighbor_line['x1'] = x1
                neighbor_line['y1'] = y1
                
            if neighbor_line['x2'] < x2:
                neighbor_line['x2'] = x2
                neighbor_line['y2'] = y2
            
        else:
            # 添加另外一条线
            # 初次填充line
            line = {}
            line['cur_k'] = k
            line['cur_b'] = b
            line['k_sum'] = k * weight
            line['b_sum'] = b * weight
            line['weight_sum'] = weight
            line['x1'] = x1
            line['y1'] = y1
            line['x2'] = x2
            line['y2'] = y2
            lines.append(line)
sorted_lines = sorted(lines, key=lambda line: line['weight_sum'])[::-1]
line1 = sorted_lines[0]
line2 = sorted_lines[1]
(cx, cy) = calculate_intersection(line1, line2)
print('cx: {} cy: {}'.format(cx, cy))
cv2.circle(img, (cx, cy), 10, (255, 0, 255), thickness=1)
cv2.imshow("img",img)
cv2.imshow("b",BlueThings)
cv2.imshow("bG",erosion)

